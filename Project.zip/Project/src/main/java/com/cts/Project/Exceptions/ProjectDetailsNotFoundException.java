package com.cts.Project.Exceptions;

public class ProjectDetailsNotFoundException extends Exception{
	private static final long serialVersionUID = 1L;

	public ProjectDetailsNotFoundException(String message) {
		super(message);
		
	}

}
